# PRM Incentive Calculator – Android App

This project wraps the final mobile PRM Incentive Calculator HTML in an Android WebView.

## Build an APK with GitHub Actions

1. Upload the contents of this project to a GitHub repository (not the ZIP itself).
2. Commit/push to the `main` branch.
3. Open the repository's **Actions** tab.
4. Select **Build PRM Calculator APK**.
5. Tap **Run workflow** if it is not already running.
6. When the workflow finishes, open the successful run.
7. Under **Artifacts**, download `PRM-Incentive-Calculator-debug`.
8. Extract the ZIP and install `app-debug.apk` on Android.

The workflow downloads Gradle 8.10.2 automatically, so a Gradle wrapper is not required.

The calculator includes the final revised logic:
- 1 point = ₹50
- Insurance premium slabs
- 125% / 100% / 75% / 50% / Not Qualified
- Gold Loan as a qualification parameter
- CASA + RTD aggregate ₹15 lakh requirement for the 50% slab
- Mobile-friendly calculator interface
