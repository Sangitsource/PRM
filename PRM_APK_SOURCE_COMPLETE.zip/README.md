# PRM Incentive Calculator Android Source

This archive contains the complete Android Studio project source. The calculator HTML is bundled locally and works offline.

Final logic includes 125%, 100%, 75%, 50%, Not Qualified; Gold Loan qualification; and CASA + RTD aggregate ₹15L for 50%.
